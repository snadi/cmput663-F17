The raw-data.csv file contains: the following columns:

ExpName: the name of the experiment replication
Id: the subject id
Fit: is the treatment: "yes" if executable Fit tables were available, "no" otherwise
Lab: the experiment lab when the task was performed
Correct: the tasks' correctness evaluation
TotalTime: The time needed to perform the tasks, including the settings
TaskTime: The time needed to perform the tasks, excluding the settings
Experience: The subjects' experience

The raw-data-paired.csv file contains the following columns:
ExpName: the name of the experiment replication
Id: the subject id
Fit: the task Correctness when using Fit tables
Text: the task Correctness when using textual requirements only
FitTotTime: the time (including the installation) to perform the tasks when using Fit tables
TextTotTime: the time (including the installation) to perform the tasks when using textual requirements
FitTaskTime: the time (excluding the installation) to perform the tasks when using Fit tables
TextTaskTime: the time (excluding the installation) to perform the tasks when using textual requirements
